William Abbot
Files:
	main.py
	Algorithm1.py
	Algorithm2.py
	Algorithm3.py
	Algorithm4.py
	phw_input.txt
	programming assignment tables.docx
	programming assignment tables.pdf
	README.txt


HOW TO COMPILE:
	If you have the latest version of python and numpy installed, 
	just doudle click the 'main.py' file and it should run. If 
	not, then open 'main.py' in IDLE (which comes with python), 
	and then press F5 to run.
	

Certification:
	I certify that I wrote the code I am submitting. I did not copy whole
	or parts of it from another student or have another person write the
	code for me. Any code I am reusing in my program is clearly marked as 
	such with its source clearly identified in comments.
